<?php

/**
 *
 * @sincen 1.0.0
 */

namespace Model\Mapper;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit();
}

/**
 * Class Settings
 * @package model
 */
class Settings
{
    /**
     * Save the data in the database
     *
     * @param string $settings
     *
     * @return bool
     */
    public static function save(string $settings): bool
    {
        return add_option('{{generator-slug}}-settings', $settings, null, 'no');
    }

    /**
     * Load the data from the database
     *
     * @return string|null
     */
    public static function find(): ?string
    {
        return get_option('{{generator-slug}}-settings');
    }

    /**
     * Delete the data from the database
     *
     * @return bool
     */
    public static function delete(): bool
    {
        return delete_option('{{generator-slug}}-settings');
    }
}
