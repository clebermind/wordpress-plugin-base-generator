<?php

/**
 *
 * @sincen 1.0.0
 */

namespace Model\Service;

use Model\Mapper;
use Model\Entity;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit();
}

/**
 * Class Settings
 * @package model
 */
class Settings
{
    /**
     * Save the data in the database
     *
     * @param Entity\Settings $settings
     * @return bool
     */
    public function save(Entity\Settings $settings): bool
    {
        Mapper\Settings::delete();

        $settings = [
            'firstName' => $settings->getFirstName(),
            'lastName' => $settings->getLastName(),
            'age' => $settings->getAge()
        ];

        return Mapper\Settings::save(json_encode($settings));
    }

    /**
     * Load the data from the database
     * @return Entity\Settings
     */
    public function load(): Entity\Settings
    {
        $data = json_decode(Mapper\Settings::find());

        $settings = new Entity\Settings();
        if (!is_null($data)) {
            $settings->setFirstName($data->firstName)
                     ->setLastName($data->lastName)
                     ->setAge($data->age);
        }

        return $settings;
    }

    /**
     * Delete the data from the database
     *
     * @return bool
     */
    public function delete(): bool
    {
        return Mapper\Settings::delete();
    }
}
