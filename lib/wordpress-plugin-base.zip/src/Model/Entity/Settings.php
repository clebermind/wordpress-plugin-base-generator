<?php

/**
 *
 * @sincen 1.0.0
 */

namespace Model\Entity;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit();
}

/**
 * Class Settings
 * @package model
 */
class Settings
{
    /**
     * @var string|null
     */
    private $firstName;

    /**
     * @var string|null
     */
    private $lastName;

    /**
     * @var string|null
     */
    private $age;

    /**
     * Settings constructor.
     *
     * @param string|null $firstName
     * @param string|null $lastName
     * @param string|null $age
     */
    public function __construct(string $firstName = null, string $lastName = null, string $age = null)
    {
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->age = $age;
    }

    /**
     * Get the First name
     *
     * @return string|null
     */
    public function getFirstName(): ?string
    {
        return $this->firstName;
    }

    /**
     * Set the First Name
     *
     * @param string $firstName
     * @return $this
     */
    public function setFirstName(string $firstName): Settings
    {
        $this->firstName = $firstName;
        return $this;
    }

    /**
     * Get the last name
     *
     * @return string|null
     */
    public function getLastName(): ?string
    {
        return $this->lastName;
    }

    /**
     * Set the last name
     *
     * @param string $lastName
     * @return $this
     */
    public function setLastName(string $lastName): Settings
    {
        $this->lastName = $lastName;
        return $this;
    }

    /**
     * Get the age
     *
     * @return int|null
     */
    public function getAge(): ?int
    {
        return $this->age;
    }

    /**
     * Get the age
     *
     * @param int $age
     * @return $this
     */
    public function setAge(int $age): Settings
    {
        $this->age = $age;
        return $this;
    }
}
