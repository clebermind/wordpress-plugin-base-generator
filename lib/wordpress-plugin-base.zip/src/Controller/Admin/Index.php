<?php

/**
 * @since 1.0.0
 */

namespace Controller\Admin;

use Controller\Controller;
use Model\Entity;
use Model\Service;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit();
}

/**
 * Class Index
 * @package controller\admin
 */
class Index extends Controller
{
    /**
     * Embed Javascript and CSS Scripts
     *
     * @return String
     */
    private function embedScripts()
    {
		wp_register_script(
		    '{{generator-slug}}-admin-script',
            {{generator-slug-capslock}}_URL . 'assets/admin/js/script.js',
            ['jquery', 'wp-i18n']
        );
		wp_enqueue_script('{{generator-slug}}-admin-script');

		wp_enqueue_style(
		    '{{generator-slug}}-admin-css',
            {{generator-slug-capslock}}_URL . 'assets/admin/css/style.css'
        );
		
		wp_enqueue_script(
		    '{{generator-slug}}-jquery-loading',
            {{generator-slug-capslock}}_URL . 'assets/components/jquery-loading/dist/jquery.loading.min.js',
            ['jquery']
        );
		wp_enqueue_style(
		    '{{generator-slug}}-jquery-loading',
            {{generator-slug-capslock}}_URL . 'assets/components/jquery-loading/dist/jquery.loading.min.css'
        );
	}

    /**
     * print the generated HTML
     *
     * @return void
     */
    public function renderPage()
    {
        $this->embedScripts();
        echo self::getTemplating()->assign('settings', (new Service\Settings())->load())
                                  ->render('Admin/index');
    }

    /**
     * Get the data validate and save or return an error
     */
    public function saveSettings()
    {
        header('Content-Type: application/json');

        $firstName = trim($this->request->request->get('firstName', ''));
        $lastName = trim($this->request->request->get('lastName', ''));
        $age = $this->request->request->get('age');

        $errors = [];
        if (empty($firstName)) {
            $errors[] = 'Must fill the first name';
        } elseif (strlen($firstName) < 2) {
            $errors[] = 'First name must be at least 2 characters long';
        }

        if (empty($lastName)) {
            $errors[] = 'Must fill the last name';
        } elseif (strlen($lastName) < 2) {
            $errors[] = 'Last name must be at least 2 characters long';
        }

        if (is_null($age)) {
            $errors[] = 'Must fill the age';
        } elseif ($age < 0) {
            $errors[] = 'Age must be equal or greater than 0';
        }

        if (count($errors) == 0) {
            $settings = new Entity\Settings();
            $settings->setFirstName($firstName)
                     ->setLastName($lastName)
                     ->setAge($age);

            if (!(new Service\Settings())->save($settings)) {
                $errors[] = 'Error when saving. Please try again later.';
            }
        }

        die(
            json_encode([
                'success' => count($errors) == 0,
                'message' => implode('.<br />', $errors)
            ])
        );
    }

}