<?php

/**
 *
 * @since 1.0.0
 */

namespace Controller;

use Controller\Controller;
use \Model\Service;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit();
}

/**
 * Class Index
 * @package controller
 */
class Index extends Controller
{
    /**
     * Embed Javascript and CSS Scripts
     *
     * @return String
     */
    private function embedScripts()
    {
		wp_register_script(
		    '{{generator-slug}}-default-script',
            {{generator-slug-capslock}}_URL . 'assets/js/script.js',
            [ 'jquery', 'wp-i18n' ]
        );
		wp_enqueue_script('{{generator-slug}}-default-script');
		wp_localize_script(
            '{{generator-slug}}-default-script',
            'the_ajax_script',
            ['ajaxurl' => admin_url('admin-ajax.php')]
        );
		
		wp_enqueue_script(
		    '{{generator-slug}}-jquery-loading-script',
            {{generator-slug-capslock}}_URL . 'assets/components/jquery-loading/dist/jquery.loading.min.js',
            ['jquery']
        );
		
		wp_enqueue_style(
		    '{{generator-slug}}-default-style',
            {{generator-slug-capslock}}_URL . 'assets/css/style.css'
        );
		wp_enqueue_style(
		    '{{generator-slug}}-jquery-loading-style',
            {{generator-slug-capslock}}_URL . 'assets/components/jquery-loading/dist/jquery.loading.min.css'
        );
	}

    /**
     * print the generated HTML
     *
     * @return void
     */
	public function renderPage()
    {
        $this->embedScripts();
        echo self::getTemplating()->assign('settings', (new Service\Settings())->load())
                                    ->render('/index');
    }

    /**
     * This dies a JSON according to the requirements.
     *
     * @return void
     */
    public function loadAge()
    {
        header('Content-Type: application/json');

        $guessedAge = $this->request->request->get('age');
        if (is_null($guessedAge)) {
            die(json_encode([
                'success' => false,
                'message' => 'Missing age field!'
                ])
            );
        } else if (!is_numeric($guessedAge)) {
            die(json_encode([
                'success' => false,
                'message' => 'Age is not a valid number!'
                ])
            );
        }

        $realAge = (new Service\Settings())->load()->getAge();
        if ($realAge) {
            die(json_encode([
                'success' => true,
                'message' => ($realAge == $guessedAge ? 'You got it!' : 'Wrong guess!'),
                'age' => $realAge
                ])
            );
        } else {
            die(json_encode([
                'success' => false,
                'message' => 'Age is not set up!'
                ])
            );
        }
    }

}