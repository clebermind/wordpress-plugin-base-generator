<?php

/**
 *
 * @since 1.0.0
 */

namespace Controller;

use Symfony\Component\HttpFoundation\Request;
use app\Templating;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit();
}

/**
 * Class Controller
 * @package controller
 */
abstract class Controller
{
    /**
     * @var Request
     */
    protected Request $request;

    /**
     * Controller constructor.
     * @return void
     */
    public function __construct()
    {
        set_time_limit(0);
        $this->request = Request::createFromGlobals();
    }

    /**
     * Get the templating object already set up
     * @return Templating
     */
    public static function getTemplating(): Templating
    {
        $template = new Templating();
        $template->setBaseDir({{generator-slug-capslock}}_PATH . '/src/View');
		
		return $template;
	}
}