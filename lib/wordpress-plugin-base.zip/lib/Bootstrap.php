<?php

/**
 * Main class
 *
 * @since       1.0.0
 */

namespace lib;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Bootstrap
{

	private static $instance = null;
	
	/**
	* Get active instance
	*
	* @access      public
	* @since       1.0.0
	* @return      self::$instance
	*/
	public static function instance()
	{
		if ( ! self::$instance ) {
			self::$instance = new self;
			self::$instance->hooks();
		}

		return self::$instance;
	}

	/**
	* Run action and filter hooks
	*
	* @access      private
	* @since       1.0.0
	* @return      void
	*/
	private function hooks()
	{

		// admin menu link
		add_action('admin_menu', array( $this, 'setup_menu' ) );

		// main view shortcode
		add_shortcode('{{generator-slug}}', array('\controller\Index', 'index'));

		$this->hooksAjax();
	}

	private function hooksAjax()
	{
		// admin ajax
		add_action('wp_ajax_save_{{generator-slug}}_settings',    array('\controller\admin\Index', 'saveSettings'));
		
		// public
		add_action('wp_ajax_nopriv_{{generator-slug}}+load_age', array('\controller\Index', 'loadAge'));
		add_action('wp_ajax_{{generator-slug}}_load_age',       array('\controller\Index', 'loadAge'));
		
	}
	
	public function setup_menu()
	{
		add_menu_page( __('{{generator-name}}', '{{generator-slug}}'), __('{{generator-name}}', '{{generator-slug}}'), 'manage_options', '{{generator-slug}}', array( $this, 'admin_page' ), 'dashicons-admin-site-alt3', 2 );
	}

	public function admin_page()
	{
		(new \controller\admin\Index());	
	}

}