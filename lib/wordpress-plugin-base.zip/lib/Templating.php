<?php
/*
The MIT License

Copyright (c) 2009 Cuong Tham
http://thecodecentral.com

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
 */
namespace lib;

class Templating
{
    private $baseDir = '.';
    private $defaultTemplateExtension = '.php';
    private $vars = [];

    public function setBaseDir($dir)
    {
        $this->baseDir = $dir;
    }

    public function getBaseDir()
    {
        return $this->baseDir;
    }

    public function assign($name, $value)
    {
        $this->vars[$name] = $value;
        return $this;
    }

    public function render($template, $show=false)
    {
        $html = $this->loadTemplate($template, $this->vars);

        if($show) {
            die($html);
        } else {
            return $html;
        }

    }

    public function setDefaultTemplateExtension($ext)
    {
        $this->defaultTemplateExtension = $ext;
    }

    public function getDefaultTemplateExtension()
    {
        return $this->defaultTemplateExtension;
    }

    public function loadTemplate($template, $vars = array(), $baseDir=null)
    {

        if($baseDir == null) {
            $baseDir = $this->getBaseDir();
        }

        $templatePath = "{$baseDir}/{$template}" . $this->getDefaultTemplateExtension();
        if(!file_exists($templatePath)) {
            throw new Exception(__('Could not include template ', 'meme-generator-admin') .$templatePath);
        }

        return $this->loadTemplateFile($templatePath, $vars);

    }

    public function renderTemplate($template, $vars = array(), $baseDir=null)
    {
        echo $this->loadTemplate($template, $vars, $baseDir);
    }

    private function loadTemplateFile($__ct___templatePath__, $__ct___vars__)
    {
        
        extract($__ct___vars__, EXTR_OVERWRITE);

        $__ct___template_return = '';
        ob_start();
        require $__ct___templatePath__;
        $__ct___template_return = ob_get_contents();
        ob_end_clean();

        return $__ct___template_return;

    }
}