<?php
/*
The MIT License

Copyright (c) 2009 Cuong Tham
http://thecodecentral.com

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
 */

namespace app;

/**
 * Class Templating
 * @package app
 */
class Templating
{
    /**
     * @var string
     */
    private $baseDir = '.';

    /**
     * @var string
     */
    private $templateExtension = 'tpl';

    /**
     * @var array
     */
    private $vars = [];

    /**
     * Set the base directory of the templates.
     *
     * @param string $dir
     * @return $this
     */
    public function setBaseDir(string $dir): Templating
    {
        $this->baseDir = $dir;
        return $this;
    }

    /**
     * Return the base directory of the templates.
     *
     * @return string
     */
    public function getBaseDir(): string
    {
        return $this->baseDir;
    }

    /**
     * Set the template extension.
     * If not set, the default is tpl.
     *
     * @param string $ext
     * @return $this
     */
    public function setTemplateExtension(string $ext): Templating
    {
        $this->templateExtension = ltrim($ext, '.');
        return $this;
    }

    /**
     * Get the template extension.
     *
     * @return string
     */
    public function getTemplateExtension(): string
    {
        return $this->templateExtension;
    }

    /**
     * Assign a variable to bw ued in the template.
     *
     * @param string $name
     * @param mixed $value
     * @return $this
     */
    public function assign(string $name, $value): Templating
    {
        $this->vars[$name] = $value;
        return $this;
    }

    /**
     * Get the HTML generated and show or return it.
     *
     * @param string $template
     * @param bool $show
     * @return String
     */
    public function render(string $template, bool $show = false): ?string
    {
        $html = $this->loadTemplate($template, $this->vars);

        if ($show) {
            die($html);
        } else {
            return $html;
        }
    }

    /**
     * Extract the variables and require the template
     * generating the HTML and returning it.
     *
     * @param string $template
     * @return String
     */
    protected function loadTemplate(string $template): string
    {
        $templatePath = "{$this->baseDir}/{$template}.{$this->templateExtension}";
        if (!file_exists($templatePath)) {
            throw new Exception(__('Could not include template ', '{{generator-slug}}') .$templatePath);
        }

        extract($this->vars, EXTR_OVERWRITE);

        ob_start();
        require $templatePath;
        $templateReturn = ob_get_contents();
        ob_end_clean();

        return $templateReturn;
    }
}
