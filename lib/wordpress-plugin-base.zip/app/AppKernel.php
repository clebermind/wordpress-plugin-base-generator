<?php

/**
 * Main class
 *
 * @since 1.0.0
 */

namespace app;

use Controller\Admin;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit();
}

/**
 * Class AppKernel
 * @package app
 */
class AppKernel
{
    /**
     * @var AppKernel
     */
    private static $instance;

    /**
     * Get active instance
     *
     * @return AppKernel
     */
    public static function instance(): AppKernel
    {
        if (!self::$instance) {
            self::$instance = new self();
            self::$instance->hooks();
        }

        return self::$instance;
    }

    /**
     * Run action and filter hooks
     *
     * @return void
     */
    private function hooks()
    {
        // admin menu link
        add_action('admin_menu', [$this, 'setupAdminMenu']);

        // main view shortcode
        add_shortcode('{{generator-slug}}', [(new \Controller\Index()), 'renderPage']);

        $this->hooksAjax();
    }

    /**
     * Add admin and public actions
     *
     * @return void
     */
    private function hooksAjax()
    {
        // admin ajax
        add_action('wp_ajax_save_{{generator-slug}}_settings', [(new \Controller\Admin\Index()), 'saveSettings']);

        // public
        add_action('wp_ajax_nopriv_{{generator-slug}}_load_age', [(new \Controller\Index()), 'loadAge']);
        add_action('wp_ajax_{{generator-slug}}_load_age', [(new \Controller\Index()), 'loadAge']);
    }

    /**
     * Set up the admin menu page
     *
     * @return void
     */
    public function setupAdminMenu()
    {
        add_menu_page(
            __('{{generator-name}}', '{{generator-slug}}'),
            __('{{generator-name}}', '{{generator-slug}}'),
            'manage_options',
            '{{generator-slug}}',
            [(new \Controller\Admin\Index()), 'renderPage'],
            'dashicons-admin-site-alt3',
            2
        );
    }
}
