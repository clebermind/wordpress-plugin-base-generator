<?php
/**
 * {{generator-name}}
 *
 * Plugin Name:     {{generator-name}}
 * Description:     {{generator-description}}
 * Author:          {{generator-author-name}}
 * Version:         1.0.0
 * Text Domain:     {{generator-slug}}
 * License:         GPL2+
 * License URI:     http://www.gnu.org/licenses/gpl-3.0.txt
 *
 */

//error_reporting(E_ALL);
//ini_set('display_errors', 1);
//ini_set('max_execution_time', 360);
 
if (!defined('ABSPATH')) {
    die( 'No script kiddies please!' );
}

define( '{{generator-slug-capslock}}_PATH', plugin_dir_path( __FILE__ ) );
define( '{{generator-slug-capslock}}_URL', plugin_dir_url( __FILE__ ) );

require_once plugin_dir_path( __FILE__ ) . 'lib/vendor/autoload.php';

\lib\Bootstrap::instance();