<?php

/**
 *
 * @since       1.0.0
 */

namespace controller\admin;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Index extends \controller\Controller
{
	
	public function __construct()
	{

		wp_register_script('{{generator-slug}}-admin-script', {{generator-slug-capslock}}_URL . 'view/admin/assets/js/script.js', array('jquery', 'wp-i18n'));
		wp_enqueue_script('{{generator-slug}}-admin-script');

		wp_enqueue_style('{{generator-slug}}-admin-css', {{generator-slug-capslock}}_URL . 'view/admin/assets/css/style.css');
		
		wp_enqueue_script('{{generator-slug}}-jquery-loading', {{generator-slug-capslock}}_URL . 'view/components/jquery-loading/dist/jquery.loading.min.js', array('jquery'));
		wp_enqueue_style('{{generator-slug}}-jquery-loading', {{generator-slug-capslock}}_URL . '/view/components/jquery-loading/dist/jquery.loading.min.css');
		
		$settings = (new \model\Settings())->load();

		$templating = $this->getTemplating();

		echo $templating->assign('settings', $settings)
			      	    ->render('admin/index');
		
	}

	public function saveSettings()
	{
		header('Content-Type: application/json');
		
		$settings = new \model\Settings();
		$settings->setFirstName(isset($_POST['firstName']) ? $_POST['firstName'] : null);
		$settings->setLastName(isset($_POST['lastName']) ? $_POST['lastName'] : null);
		$settings->setAge(isset($_POST['age']) ? $_POST['age'] : null);
		
		if($settings->save()) {
			die(json_encode(['success'=>true]));
		} else {
			die(json_encode(['success'=>false]));
		}

	}

}