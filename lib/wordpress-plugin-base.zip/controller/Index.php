<?php

/**
 *
 * @since       1.0.0
 */

namespace controller;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Index extends \controller\Controller
{
	
	public function index()
	{

		wp_register_script('{{generator-slug}}-default-script', {{generator-slug-capslock}}_URL . 'view/assets/js/script.js',array( 'jquery', 'wp-i18n' ));
		wp_enqueue_script('{{generator-slug}}-default-script');
		wp_localize_script('{{generator-slug}}-default-script', 'the_ajax_script', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
		
		wp_enqueue_script('{{generator-slug}}-jquery-loading-script', {{generator-slug-capslock}}_URL . 'view/components/jquery-loading/dist/jquery.loading.min.js',array( 'jquery'));
		
		wp_enqueue_style('{{generator-slug}}-default-style', {{generator-slug-capslock}}_URL . 'view/assets/css/style.css');
		wp_enqueue_style('{{generator-slug}}-jquery-loading-style', {{generator-slug-capslock}}_URL . 'view/components/jquery-loading/dist/jquery.loading.min.css');

		$templating = self::getTemplating();
		return $templating->assign('settings', (new \model\Settings())->load())
						  ->render('/index');
		
	}
	
	public function loadAge()
	{
		
		header('Content-Type: application/json');
		
		if(!isset($_POST['age'])) {
			die(json_encode([
					'success' => false,
					'message' => 'Missing age field!'
				])
			);
		} else if(!is_numeric($_POST['age'])) {
			die(json_encode([
					'success' => false,
					'message' => 'Age is not a valid number!'
				])
			);
		}
		
		$age = (new \model\Settings())->load()->getAge();
		if($age) {
			
			die(json_encode([
					'success' => true,
					'message' => ($age==$_POST['age'] ? 'You got it!' : 'Wrong guess!'),
					'age' => $age
				])
			);
			
		} else {
			die(json_encode([
					'success' => false,
					'message' => 'Age is not set up!'
				])
			);
		}
		
	}
	
}