<?php

/**
 *
 * @since       1.0.0
 */

namespace controller;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Controller
{
	
	public function __construct()
    {
        set_time_limit();
    }

	public static function getTemplating()
	{
		$template = new \lib\Templating();
        $template->setBaseDir({{generator-slug-capslock}}_PATH . '/view');
		$template->setDefaultTemplateExtension('.tpl');
		
		return $template;
	}
	
}