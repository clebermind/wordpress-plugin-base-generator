(function($) {
    jQuery(document).ready(function() {
        
        jQuery("#simple-view-age").keydown(function(event){
            if(event.keyCode == 13) {
                event.preventDefault();
                jQuery('#simple-view-age-btn').trigger('click');
                return false;
            }
        });
        
        jQuery('#simple-view-age-btn').on('click', function(){
            
            if (!jQuery('#simple-view-age').val()) {
                alert('Please guess an age!');
                return false;
            }
           
            jQuery('.simple-view').loading({
                message: 'Working...',
                onStart: function(loading) {
                    loading.overlay.slideDown(400);
                }
            });
            
            var data = {
                'action': '{{generator-slug}}_load_age',
                'age': jQuery('#simple-view-age').val()
            };
            
            jQuery("body").focus(); //remove focus from the button
            
            jQuery.ajax({
                url: the_ajax_script.ajaxurl,
                data: data,
                type:"POST",
                cache:false,
                dataType:"json",
                error:function(err) {
                    jQuery('.simple-view').loading('destroy');
                    alert('An error occurred. Please try again later.');
                },
                success:function(response) {
                    
                    if (response.success) {
                        
                        jQuery('.simple-view p:last').remove();
                        jQuery('.simple-view').append("<p><label>Age:</label> " + response.age + " (" + response.message + ")</p>");
                        
                    } else {
                        alert(esponse.message);
                    }
                    
					jQuery('.simple-view').loading('destroy');
                }
            });
        
        });
        
    });
})(jQuery);