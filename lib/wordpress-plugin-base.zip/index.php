<?php
// Silence is good