const { __, _x, _n, sprintf } = wp.i18n;

(function($) {
    jQuery(document).ready(function() {
 
        jQuery('#save-settings').on('click', function(){
            
            if(!jQuery('#first-name').val()) {
                jQuery('#action-msg-settings').attr('class', 'error notice');
                jQuery('#action-msg-settings p').html(__('First name required!', '{{generator-slug}}-admin-js'));
                return false;
            } else if(!jQuery('#last-name').val()) {
                jQuery('#action-msg-settings').attr('class', 'error notice');
                jQuery('#action-msg-settings p').html(__('Last name required!', '{{generator-slug}}-admin-js'));
                return false;
            } else if(!jQuery('#age').val()) {
                jQuery('#action-msg-settings').attr('class', 'error notice');
                jQuery('#action-msg-settings p').html(__('Age required!', '{{generator-slug}}-admin-js'));
                return false;
            }
            
            jQuery('#{{generator-slug}}-panel-item-settings').loading({ 
                message: 'Working...'
			});
            
            jQuery('#action-msg-settings, #save-settings').hide();

            var data = { 'action': 'save_{{generator-slug}}_settings' };
            jQuery('#form-settings input, #form-settings textarea, #form-settings select').each(function(i, obj){
                if(jQuery(obj).attr('type')=='radio') {
                    data[jQuery(obj).attr('name')] = jQuery('input[name="'+jQuery(obj).attr('name')+'"]:checked').val();
                } else if(jQuery(obj).attr('type')=='checkbox') {
                    var temp = {};
                    jQuery('input[name="'+jQuery(obj).attr('name')+'"]:checked').each(function(i, obj){
                        temp[i] = jQuery(obj).val();
                    });
                    data[jQuery(obj).attr('name')] = temp;
                } else {
                    data[jQuery(obj).attr('name')] = jQuery(obj).val();
                }
            });

            $.ajax({
                url: ajaxurl,
                data: data,
                dataType: 'json',
                type: 'POST',
                success: function(resp) {
                    
                    jQuery('#{{generator-slug}}-panel-item-settings').loading('destroy');
                    
                    if(resp.success) {
                        jQuery('#action-msg-settings').attr('class', 'updated notice');
                        jQuery('#action-msg-settings p').html(__('Settings has been updated, awesome!', '{{generator-slug}}-admin-js'));
                    } else {
                        jQuery('#action-msg-settings').attr('class', 'error notice');
                        if(resp.message){
                            jQuery('#action-msg-settings p').html(resp.message);
                        } else {
                            jQuery('#action-msg-settings p').html(__('Ops... Something went wrong. =(', '{{generator-slug}}-admin-js'));
                        }
                    }
                    
                    jQuery('#action-msg-settings, #save-settings').show();
                    
                },
                error: function(e) {
                    jQuery('#{{generator-slug}}-panel-item-settings').loading('destroy');
                    jQuery('#action-msg-settings').attr('class', 'error notice');
                    jQuery('#action-msg-settings p').html(__('Error trying to connect the server. =(', '{{generator-slug}}-admin-js'));
                    jQuery('#action-msg-settings').show();
                }
            });
        });
        
    });
    
})(jQuery);
