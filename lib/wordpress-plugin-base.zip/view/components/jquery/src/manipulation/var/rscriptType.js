define( function() {
	"use strict";

	return ( /^$|^module$|\/(?:java|ecma)script/i );
} );
